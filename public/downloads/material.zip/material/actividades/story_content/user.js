function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5phXkGuCk8o":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

